//
//  AppDelegate.h
//  QuickStartObjcExampleApp
//
//  Created by Joren Winge on 11/28/17.
//  Copyright © 2017 Back4App. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

